<?php
/**
 * Plugin Name: DevAmir Elementor Widget
 */
defined( 'ABSPATH' ) || exit;

// تعریف ثابت‌ها
define( 'DEVAMIR_WIDGET_PATH', plugin_dir_path( __FILE__ ) );
define( 'DEVAMIR_WIDGET_URL', plugin_dir_url( __FILE__ ) );
define( 'DEVAMIR_ASSETS_URL', DEVAMIR_WIDGET_URL . 'assets/' );
define( 'DEVAMIR_ASSETS_js_url', DEVAMIR_WIDGET_URL . 'assets/js/' );
define( 'DEVAMIR_ASSETS_css_url', DEVAMIR_WIDGET_URL . 'assets/css/' );
define( 'DEVAMIR_WIDGETS_PATH', DEVAMIR_WIDGET_PATH . 'elementor-widget/' );
define( 'DEVAMIR_INCLUDE_PATH', DEVAMIR_WIDGET_PATH . 'include/' );

// لود فایل‌های ضروری
include_once DEVAMIR_INCLUDE_PATH . 'enqueue.php';

// تابع ثبت همه ویجت‌ها
function devamir_register_elementor_widgets( $widgets_manager ) {

    require_once DEVAMIR_WIDGETS_PATH . 'My-Custom-Widget.php';
    $widgets_manager->register( new \My_Custom_Widget() );

//    require_once DEVAMIR_WIDGETS_PATH . 'Elementor_Test_Widget.php';
//    $widgets_manager->register( new \Elementor_Test_Widget() );

    require_once DEVAMIR_WIDGETS_PATH . 'Elementor-Widget-Slider.php';
    $widgets_manager->register( new \Elementor_Widget_Slider() );
}

add_action( 'elementor/widgets/register', 'devamir_register_elementor_widgets' );
