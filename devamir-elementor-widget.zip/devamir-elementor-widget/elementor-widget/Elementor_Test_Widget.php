<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class Elementor_Widget_Slider extends Widget_Base {

    public function get_name() {
        return 'devamir_slider';
    }

    public function get_title() {
        return 'DevAmir Slider';
    }

    public function get_icon() {
        return 'eicon-slider-album';
    }

    public function get_categories() {
        return [ 'basic' ];
    }

    public function get_script_depends() {
        return [ 'devamir-swiper-js' ];
    }

    public function get_style_depends() {
        return [ 'devamir-swiper-css' ];
    }

    public function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => 'اسلایدها',
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'slide_image',
            [
                'label' => 'تصویر اسلاید',
                'type'  => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'slide_title',
            [
                'label' => 'عنوان',
                'type'  => Controls_Manager::TEXT,
                'default' => 'عنوان اسلاید',
            ]
        );

        $this->add_control(
            'slides',
            [
                'label' => 'لیست اسلایدها',
                'type'  => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [],
            ]
        );

        $this->end_controls_section();
    }

    public function render() {
        $settings = $this->get_settings_for_display();

        if ( empty( $settings['slides'] ) ) return;

        ?>
        <div class="devamir-slider-container">
            <div class="swiper main-swiper">
                <div class="swiper-wrapper">
                    <?php foreach ( $settings['slides'] as $slide ) : ?>
                        <div class="swiper-slide">
                            <img src="<?php echo esc_url( $slide['slide_image']['url'] ); ?>" alt="">
                            <h4><?php echo esc_html( $slide['slide_title'] ); ?></h4>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="swiper thumbs-swiper">
                <div class="swiper-wrapper">
                    <?php foreach ( $settings['slides'] as $slide ) : ?>
                        <div class="swiper-slide">
                            <img src="<?php echo esc_url( $slide['slide_image']['url'] ); ?>" alt="" />
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }
}
