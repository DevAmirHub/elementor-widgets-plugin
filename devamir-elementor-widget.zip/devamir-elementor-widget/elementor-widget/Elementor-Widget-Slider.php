<?php
defined( 'ABSPATH' ) || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class Elementor_Widget_Slider extends Widget_Base {

    public function get_name() {
        return 'devamir_synced_slider';
    }

    public function get_title() {
        return 'Devamir Synced Slider';
    }

    public function get_icon() {
        return 'eicon-slider-album';
    }

    public function get_categories() {
        return [ 'basic' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => 'Images',
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'image',
            [
                'label' => 'Image',
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => 'https://via.placeholder.com/800x600',
                ],
            ]
        );

        $this->add_control(
            'slider_items',
            [
                'label' => 'Slider Images',
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'thumbnail_styles_section',
            [
                'label' => esc_html__( 'Thumbnail Style', 'devamir' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

// عرض و ارتفاع
        $this->add_responsive_control(
            'thumbnail_size',
            [
                'label' => esc_html__( 'Thumbnail Size', 'devamir' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 200,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 80,
                ],
                'selectors' => [
                    '{{WRAPPER}} .thumbs-swiper .swiper-slide img' => 'width: {{SIZE}}{{UNIT}}; height: auto;',
                ],
            ]
        );

// فاصله بین تامبنیل‌ها
        $this->add_responsive_control(
            'thumbnail_spacing',
            [
                'label' => esc_html__( 'Thumbnail Spacing', 'devamir' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thumbs-swiper .swiper-slide' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

// حاشیه برای تامبنیل فعال
        $this->add_control(
            'active_thumb_border',
            [
                'label' => esc_html__( 'Active Thumbnail Border Color', 'devamir' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thumbs-swiper .swiper-slide-thumb-active img' => 'border: 2px solid {{VALUE}};',
                ],
            ]
        );

// گردی گوشه
        $this->add_control(
            'thumbnail_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'devamir' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .thumbs-swiper .swiper-slide img' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();


        //style tab
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__( 'Slider Style', 'devamir' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Image Width
        $this->add_responsive_control(
            'main_image_width',
            [
                'label' => esc_html__( 'Main Image Width', 'devamir' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ '%', 'px', 'vw' ],
                'range' => [
                    '%' => [ 'min' => 10, 'max' => 100 ],
                    'px' => [ 'min' => 100, 'max' => 2000 ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .main-swiper .swiper-slide img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Image Border Radius
        $this->add_responsive_control(
            'main_image_radius',
            [
                'label' => esc_html__( 'Main Image Radius', 'devamir' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .main-swiper .swiper-slide img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Main Image Height (optional)
        $this->add_responsive_control(
            'main_image_height',
            [
                'label' => esc_html__( 'Main Image Height', 'devamir' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
                'range' => [
                    'px' => [ 'min' => 100, 'max' => 1000 ],
                    'vh' => [ 'min' => 10, 'max' => 100 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .main-swiper .swiper-slide img' => 'height: {{SIZE}}{{UNIT}}; object-fit: cover;',
                ],
            ]
        );
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="devamir-slider-container">
            <div class="swiper main-swiper">
                <div class="swiper-wrapper">
                    <?php foreach ( $settings['slider_items'] as $item ) : ?>
                        <div class="swiper-slide">
                            <img src="<?php echo esc_url($item['image']['url']); ?>" />
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="swiper thumbs-swiper">
                <div class="swiper-wrapper">
                    <?php foreach ( $settings['slider_items'] as $item ) : ?>
                        <div class="swiper-slide">
                            <img src="<?php echo esc_url($item['image']['url']); ?>" />
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }
}
