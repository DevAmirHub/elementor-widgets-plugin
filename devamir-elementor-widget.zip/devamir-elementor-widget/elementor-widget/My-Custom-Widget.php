<?php
defined( 'ABSPATH' ) || exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;

//class My_Custom_Widget extends \Elementor\Widget_Base {
//    public function get_name() {
//        return 'my_custom_widget';
//    }
//
//    public function get_title() {
//        return 'ویجت سفارشی من';
//    }
//
//    public function get_icon() {
//        return 'eicon-code';
//    }
//
//    public function get_categories() {
//        return ['basic'];
//    }
//
//    public function has_widget_inner_wrapper(): bool {
//        return true;
//    }
//
//    protected function is_dynamic_content(): bool {
//        return true;
//    }
//
//
//    protected function register_controls() {
//        $this->start_controls_section(
//            'content_section',
//            [
//                'label' => 'تنظیمات محتوا',
//                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
//            ]
//        );
//
//        $this->add_control(
//            'title_text',
//            [
//                'label' => 'عنوان',
//                'type' => \Elementor\Controls_Manager::TEXT,
//                'default' => 'سلام دنیا!',
//            ]
//        );
//
//        $this->add_control(
//            'title_image',
//            [
//                'label' => 'تصویر',
//                'type' => \Elementor\Controls_Manager::MEDIA,
//                'default' => [
//                    'url' => 'https://example.com/wp-content/uploads/your-default-image.jpg',
//                ],
//            ]
//        );
//
//
//        $this->end_controls_section();
//
//    }
//
//    protected function render() {
//        $settings = $this->get_settings_for_display();
//        echo '<h2>' . esc_html($settings['title_text']) . '</h2>';
////        $settings = $this->get_settings_for_display();
//        if ( ! empty( $settings['title_image']['url'] ) ) {
//            echo '<img src="' . esc_url( $settings['title_image']['url'] ) . '" alt="تصویر">';
//        }
//    }





//    public function get_name()
//    {
//        return 'my_custom_widget';
//    }
//
//    public function get_title()
//    {
//        return 'ویجت سفارشی من';
//    }
//
//    public function get_icon()
//    {
//        return 'eicon-code';
//    }
//
//    public function get_categories()
//    {
//        return ['basic'];
//    }
//
//    public function has_widget_inner_wrapper(): bool
//    {
//        return true;
//    }
//
//    protected function is_dynamic_content(): bool
//    {
//        return true;
//    }

//    protected function register_controls(): void
//    {
//        $this->start_controls_section(
//            'content_section',
//            [
//                'label' => 'تنظیمات محتوا',
//                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
//            ]
//        );
//
//        $this->add_control(
//            'title_text',
//            [
//                'label' => 'عنوان',
//                'type' => \Elementor\Controls_Manager::TEXT,
//                'default' => 'سلام دنیا!',
//            ]
//        );
//
//        $this->add_control(
//            'title_image',
//            [
//                'label' => 'تصویر',
//                'type' => \Elementor\Controls_Manager::MEDIA,
//                'default' => [
//                    'url' => 'https://example.com/wp-content/uploads/your-default-image.jpg',
//                ],
//            ]
//        );
//
//        $this->add_control(
//            'size',
//            [
//                'type' => \Elementor\Controls_Manager::NUMBER,
//                'label' => 'اندازه',
//                'default' => 50,
//                'min' => 0,
//                'max' => 100,
//                'step' => 10,
//            ]
//        );
//
//        $this->add_control(
//            'open_lightbox',
//            [
//                'type' => \Elementor\Controls_Manager::SELECT,
//                'label' => 'لایت‌باکس',
//                'options' => [
//                    'default' => 'پیش‌فرض',
//                    'yes' => 'بله',
//                    'no' => 'خیر',
//                ],
//                'default' => 'no',
//            ]
//        );
//
//        $this->add_control(
//            'alignment',
//            [
//                'type' => \Elementor\Controls_Manager::CHOOSE,
//                'label' => 'تراز',
//                'options' => [
//                    'left' => [
//                        'title' => 'چپ',
//                        'icon' => 'eicon-text-align-left',
//                    ],
//                    'center' => [
//                        'title' => 'مرکز',
//                        'icon' => 'eicon-text-align-center',
//                    ],
//                    'right' => [
//                        'title' => 'راست',
//                        'icon' => 'eicon-text-align-right',
//                    ],
//                ],
//                'default' => 'center',
//            ]
//        );
//
//        $this->end_controls_section();
//    }

//    protected function render(): void
//    {
//        $settings = $this->get_settings_for_display();
//
//        $title = $settings['title_text'] ?? '';
//        $image_url = $settings['title_image']['url'] ?? '';
//        $size = intval($settings['size'] ?? 50);
//        $lightbox = $settings['open_lightbox'] ?? 'no';
//        $alignment = $settings['alignment'] ?? 'center';
//
//        $style = sprintf(
//            'font-size: %dpx; text-align: %s;',
//            $size,
//            esc_attr($alignment)
//        );
//
//        if ($title) {
//            echo '<h2 style="' . esc_attr($style) . '">' . esc_html($title) . '</h2>';
//        }
//
//        if ($image_url) {
//            echo '<img src="' . esc_url($image_url) . '" alt="تصویر">';
//        }
//
//        if ($lightbox === 'yes') {
//            echo '<p>لایت‌باکس فعال است.</p>';
//        } elseif ($lightbox === 'no') {
//            echo '<p>لایت‌باکس غیر فعال است.</p>';
//        } else {
//            echo '<p>لایت‌باکس حالت پیش‌فرض است.</p>';
//        }
//    }







//    protected function register_controls() {
//
//        $this->start_controls_section(
//            'section_content',
//            [
//                'label' => __( 'محتوا', 'textdomain' ),
//            ]
//        );
//
//        // کنترل عنوان
//        $this->add_control(
//            'my_title',
//            [
//                'label' => __( 'عنوان', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::TEXT,
//                'default' => __( 'عنوان من', 'textdomain' ),
//                'placeholder' => __( 'اینجا بنویس...', 'textdomain' ),
//            ]
//        );

//        // کنترل رنگ عنوان
//        $this->add_control(
//            'my_title_color',
//            [
//                'label' => __( 'رنگ عنوان', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::COLOR,
//                'default' => '#FF0000',
//                'selectors' => [
//                    '{{WRAPPER}} .my-title' => 'color: {{VALUE}};',
//                ],
//            ]
//        );
//
//        // کنترل تصویر
//        $this->add_control(
//            'my_image',
//            [
//                'label' => __( 'تصویر', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::MEDIA,
//                'default' => [
//                    'url' => \Elementor\Utils::get_placeholder_image_src(),
//                ],
//            ]
//        );
//
//        // سوییچ نمایش/عدم نمایش عنوان
//        $this->add_control(
//            'show_title',
//            [
//                'label' => __( 'نمایش عنوان؟', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::SWITCHER,
//                'label_on' => 'بله',
//                'label_off' => 'خیر',
//                'return_value' => 'yes',
//                'default' => 'yes',
//            ]
//        );
//
//        $this->end_controls_section();
//    }
//
//
//    protected function render() {
//        $settings = $this->get_settings_for_display();
//
//        if ( 'yes' === $settings['show_title'] ) {
//            echo '<h2 class="my-title">' . esc_html( $settings['my_title'] ) . '</h2>';
//        }
//
//        if ( ! empty( $settings['my_image']['url'] ) ) {
//            echo '<img src="' . esc_url( $settings['my_image']['url'] ) . '" alt="">';
//        }
//    }
//
//
//
//    protected function content_template(): void {
//        ?>
<!--        <# if ( settings.show_title === 'yes' ) { #>-->
<!--        <h2 class="my-title" style="color: {{ settings.my_title_color }}">{{{ settings.my_title }}}</h2>-->
<!--        <# } #>-->
<!---->
<!--        <# if ( settings.my_image.url ) { #>-->
<!--        <img src="{{ settings.my_image.url }}" alt="">-->
<!--        <# } #>-->
<!--        --><?php
//    }
//
//
//
//}






//class My_Custom_Widget extends \Elementor\Widget_Base {
//
//
//    public function get_name()
//    {
//        return 'my_custom_widget';
//    }
//
//    public function get_title()
//    {
//        return 'ویجت سفارشی من';
//    }
//
//    public function get_icon()
//    {
//        return 'eicon-code';
//    }
//
//    public function get_categories()
//    {
//        return ['basic'];
//    }
//
//    public function has_widget_inner_wrapper(): bool
//    {
//        return true;
//    }
//
//    protected function is_dynamic_content(): bool
//    {
//        return true;
//    }
//
//    protected function register_controls(): void {
//
//        $this->start_controls_section(
//            'section_content',
//            [
//                'label' => esc_html__( 'Content', 'textdomain' ),
//                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
//            ]
//        );
//
//        $this->add_control(
//            'title',
//            [
//                'label' => esc_html__( 'Title', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::TEXT,
//                'placeholder' => esc_html__( 'Enter your title', 'textdomain' ),
//
//            ]
//        );
//
//        $this->end_controls_section();
//
//
//
//
//
//
//        $this->start_controls_section(
//            'section_style',
//            [
//                'label' => esc_html__( 'Style', 'textdomain' ),
//                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
//            ]
//        );
//
//        $this->add_control(
//            'color',
//            [
//                'label' => esc_html__( 'Color', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::COLOR,
//                'default' => '#f00',
//                'selectors' => [
//                    '{{WRAPPER}} h3' => 'color: {{VALUE}}',
//                ],
//            ]
//        );
//
//        $this->add_control(
//            'title_font_size',
//            [
//                'label' => __( 'سایز فونت عنوان', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::SLIDER,
//                'size_units' => [ 'px', 'em', 'rem' ],
//                'range' => [
//                    'px' => [
//                        'min' => 10,
//                        'max' => 100,
//                        'step' => 1,
//                    ],
//                    'em' => [
//                        'min' => 0.5,
//                        'max' => 10,
//                        'step' => 0.1,
//                    ],
//                    'rem' => [
//                        'min' => 0.5,
//                        'max' => 10,
//                        'step' => 0.1,
//                    ],
//                ],
//                'default' => [
//                    'unit' => 'px',
//                    'size' => 24,
//                ],
//                'selectors' => [
//                    '{{WRAPPER}} .title' => 'font-size: {{SIZE}}{{UNIT}};',
//                ],
//            ]
//        );
//
//        $this->end_controls_section();
//
//    }
//
//    protected function render(): void {
//        $settings = $this->get_settings_for_display();
//
//        if ( empty( $settings['title'] ) ) {
//            return;
//        }
//        ?>
<!--        <h3 class="title">-->
<!--            --><?php //echo $settings['title']; ?>
<!--        </h3>-->
<!--        --><?php
//    }
//
//    protected function content_template(): void {
//        ?>
<!--        <#-->
<!--        if ( '' === settings.title ) {-->
<!--        return;-->
<!--        }-->
<!--        #>-->
<!--        <h3 class="title">-->
<!--            {{{ settings.title }}}-->
<!--        </h3>-->
<!--        --><?php
//    }
//
//}







//class My_Custom_Widget extends \Elementor\Widget_Base {
//
//    public function get_name() {
//        return 'advanced_image_widget';
//    }
//
//    public function get_title() {
//        return 'Advanced Image Rendering';
//    }
//
//    public function get_icon() {
//        return 'eicon-image';
//    }
//
//    public function get_categories() {
//        return ['basic'];
//    }
//
//    protected function register_controls() {
//
//        // بخش محتوا - انتخاب تصویر
//        $this->start_controls_section(
//            'content_section',
//            [
//                'label' => __( 'Content', 'textdomain' ),
//                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
//            ]
//        );
//
//        $this->add_control(
//            'image',
//            [
//                'label' => __( 'Choose Image', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::MEDIA,
//                'default' => [
//                    'url' => \Elementor\Utils::get_placeholder_image_src(),
//                ],
//            ]
//        );
//
//        $this->end_controls_section();
//
//        // بخش استایل - تنظیمات ظاهر
//        $this->start_controls_section(
//            'style_section',
//            [
//                'label' => __( 'Style', 'textdomain' ),
//                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
//            ]
//        );
//
//        // اندازه عرض عکس (عرض به درصد یا px یا ...)
//        $this->add_control(
//            'image_width',
//            [
//                'label' => __( 'Width', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::SLIDER,
//                'size_units' => [ 'px', '%', 'em', 'rem' ],
//                'range' => [
//                    'px' => [ 'min' => 50, 'max' => 1200 ],
//                    '%'  => [ 'min' => 10, 'max' => 100 ],
//                ],
//                'default' => [
//                    'unit' => 'px',
//                    'size' => 300,
//                ],
//                'selectors' => [
//                    '{{WRAPPER}} img.advanced-image' => 'width: {{SIZE}}{{UNIT}};',
//                ],
//            ]
//        );
//
//        // گردی گوشه عکس
//        $this->add_control(
//            'border_radius',
//            [
//                'label' => __( 'Border Radius', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::SLIDER,
//                'size_units' => [ 'px', '%' ],
//                'range' => [
//                    'px' => [ 'min' => 0, 'max' => 100 ],
//                    '%'  => [ 'min' => 0, 'max' => 50 ],
//                ],
//                'default' => [
//                    'unit' => 'px',
//                    'size' => 0,
//                ],
//                'selectors' => [
//                    '{{WRAPPER}} img.advanced-image' => 'border-radius: {{SIZE}}{{UNIT}};',
//                ],
//            ]
//        );
//
//        // سایه عکس
//        $this->add_control(
//            'box_shadow',
//            [
//                'label' => __( 'Box Shadow', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::BOX_SHADOW,
//                'selectors' => [
//                    '{{WRAPPER}} img.advanced-image' => 'box-shadow: {{VALUE}};',
//                ],
//            ]
//        );
//
//        $this->end_controls_section();
//    }
//
//    protected function render() {
//        $settings = $this->get_settings_for_display();
//
//        // اگر تصویری انتخاب نشده باشه، تصویر پیش‌فرض نمایش داده میشه
//        $image_url = $settings['image']['url'] ?? \Elementor\Utils::get_placeholder_image_src();
//
//        echo '<img class="advanced-image" src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Advanced Image', 'textdomain' ) . '">';
//    }
//}




//class My_Custom_Widget extends \Elementor\Widget_Base {
//
//    public function get_name() {
//        return 'advanced_image_rendering'; // اسلاگ ویجت
//    }
//
//    public function get_title() {
//        return 'Advanced Image Rendering'; // عنوان قابل نمایش در پنل المنتور
//    }
//
//    public function get_icon() {
//        return 'eicon-code';
//    }
//
//    public function get_categories() {
//        return ['basic'];
//    }
//
//    public function has_widget_inner_wrapper(): bool {
//        return true;
//    }
//
//    protected function register_controls(): void {
//
//        $this->start_controls_section(
//            'section_content',
//            [
//                'label' => esc_html__( 'Content', 'textdomain' ),
//                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
//            ]
//        );
//
//        $this->add_control(
//            'list',
//            [
//                'label' => esc_html__( 'List', 'textdomain' ),
//                'type' => \Elementor\Controls_Manager::REPEATER,
//                'fields' => [
//                    [
//                        'name' => 'text',
//                        'label' => esc_html__( 'Text', 'textdomain' ),
//                        'type' => \Elementor\Controls_Manager::TEXT,
//                        'placeholder' => esc_html__( 'List Item', 'textdomain' ),
//                        'default' => esc_html__( 'List Item', 'textdomain' ),
//                    ],
//                    [
//                        'name' => 'link',
//                        'label' => esc_html__( 'Link', 'textdomain' ),
//                        'type' => \Elementor\Controls_Manager::URL,
//                        'placeholder' => esc_html__( 'https://your-link.com', 'textdomain' ),
//                    ],
//                ],
//                'default' => [
//                    [
//                        'text' => esc_html__( 'List Item #1', 'textdomain' ),
//                        'link' => 'https://elementor.com/',
//                    ],
//                    [
//                        'text' => esc_html__( 'List Item #2', 'textdomain' ),
//                        'link' => 'https://elementor.com/',
//                    ],
//                ],
//                'title_field' => '{{{ text }}}',
//            ]
//        );
//
//        $this->end_controls_section();
//
//    }
//
//    protected function render(): void {
//        $settings = $this->get_settings_for_display();
//
//        if ( ! $settings['list'] ) {
//            return;
//        }
//        ?>
<!--        <ul>-->
<!--            --><?php //foreach ( $settings['list'] as $index => $item ) : ?>
<!--                <li>-->
<!--                    --><?php
//                    if ( $item['link']['url'] ) {
//                        ?><!--<a href="--><?php //echo esc_url( $item['link']['url'] ); ?><!--">--><?php //echo $item['text']; ?><!--</a>--><?php
//                    } else {
//                        echo $item['text'];
//                    }
//                    ?>
<!--                </li>-->
<!--            --><?php //endforeach; ?>
<!--        </ul>-->
<!--        --><?php
//    }
//
//    protected function content_template(): void {
//        ?>
<!--        <#-->
<!--        if ( ! settings.list.length ) {-->
<!--        return;-->
<!--        }-->
<!--        #>-->
<!--        <ul>-->
<!--            <# _.each( settings.list, function( item, index ) { #>-->
<!--            <li>-->
<!--                <# if ( item.link && item.link.url ) { #>-->
<!--                <a href="{{{ item.link.url }}}">{{{ item.text }}}</a>-->
<!--                <# } else { #>-->
<!--                {{{ item.text }}}-->
<!--                <# } #>-->
<!--            </li>-->
<!--            <# } ); #>-->
<!--        </ul>-->
<!--        --><?php
//    }
//
//}



class My_Custom_Widget extends Widget_Base {

    public function get_name() {
        return 'advanced_image_rendering';
    }

    public function get_title() {
        return 'Advanced Image Rendering';
    }

    public function get_icon() {
        return 'eicon-image';
    }

    public function get_categories() {
        return ['general'];
    }

//    protected function register_controls() {
//
//        // --- تب کانتنت ---
//        $this->start_controls_section(
//            'content_section',
//            [
//                'label' => 'محتوا',
//                'tab' => Controls_Manager::TAB_CONTENT,
//            ]
//        );
//
//        $this->add_control(
//            'image',
//            [
//                'label' => 'انتخاب تصویر',
//                'type' => Controls_Manager::MEDIA,
//                'default' => [
//                    'url' => \Elementor\Utils::get_placeholder_image_src(),
//                ],
//            ]
//        );
//
//        $this->add_control(
//            'image_alt',
//            [
//                'label' => 'متن جایگزین',
//                'type' => Controls_Manager::TEXT,
//                'default' => 'تصویر نمونه',
//            ]
//        );
//
//        $this->end_controls_section();
//
//        // --- تب استایل ---
//        $this->start_controls_section(
//            'style_section',
//            [
//                'label' => 'استایل',
//                'tab' => Controls_Manager::TAB_STYLE,
//            ]
//        );
//
//        $this->add_control(
//            'image_color',
//            [
//                'label' => 'رنگ فیلتر تصویر',
//                'type' => Controls_Manager::COLOR,
//                'default' => '',
//                'selectors' => [
//                    '{{WRAPPER}} .custom-image' => 'filter: brightness(0) saturate(100%) invert(28%) sepia(47%) saturate(470%) hue-rotate(165deg) brightness(92%) contrast(88%) drop-shadow(0 0 0 {{VALUE}});',
//                ],
//            ]
//        );
//
//        $this->add_responsive_control(
//            'image_font_size',
//            [
//                'label' => 'سایز متن جایگزین',
//                'type' => Controls_Manager::SLIDER,
//                'size_units' => ['px', 'em', '%'],
//                'range' => [
//                    'px' => [
//                        'min' => 10,
//                        'max' => 100,
//                    ],
//                ],
//                'selectors' => [
//                    '{{WRAPPER}} .image-alt' => 'font-size: {{SIZE}}{{UNIT}};',
//                ],
//            ]
//        );
//
//        $this->end_controls_section();
//    }

//    protected function render() {
//        $settings = $this->get_settings_for_display();
//
//        $this->add_render_attribute('image-wrapper', [
//            'class' => 'custom-image-wrapper',
//            'style' => 'text-align: center;',
//        ]);
//
//        $this->add_render_attribute('image', [
//            'src' => esc_url($settings['image']['url']),
//            'alt' => esc_attr($settings['image_alt']),
//            'class' => 'custom-image',
//        ]);
//
//        $this->add_render_attribute('alt-text', [
//            'class' => 'image-alt',
//        ]);
//
//        echo '<div ' . $this->get_render_attribute_string('image-wrapper') . '>';
//        echo '<img ' . $this->get_render_attribute_string('image') . ' />';
//        echo '<div ' . $this->get_render_attribute_string('alt-text') . '>';
//        echo esc_html($settings['image_alt']);
//        echo '</div>';
//        echo '</div>';
//    }













//inline style
    protected function register_controls(): void {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'textdomain' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__( 'Title', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Title', 'textdomain' ),
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => esc_html__( 'Description', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( 'Description', 'textdomain' ),
            ]
        );

        $this->add_control(
            'content',
            [
                'label' => esc_html__( 'Content', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => esc_html__( 'Content', 'textdomain' ),
            ]
        );

        $this->end_controls_section();

    }

    protected function render(): void {
        $settings = $this->get_settings_for_display();

        $this->add_inline_editing_attributes( 'title', 'none' );
        $this->add_inline_editing_attributes( 'description', 'basic' );
        $this->add_inline_editing_attributes( 'content', 'advanced' );
        ?>
        <h2 <?php $this->print_render_attribute_string( 'title' ); ?>><?php echo $settings['title']; ?></h2>
        <div <?php $this->print_render_attribute_string( 'description' ); ?>><?php echo $settings['description']; ?></div>
        <div <?php $this->print_render_attribute_string( 'content' ); ?>><?php echo $settings['content']; ?></div>
        <?php
    }

    protected function content_template(): void {
        ?>
        <#
        view.addInlineEditingAttributes( 'title', 'none' );
        view.addInlineEditingAttributes( 'description', 'basic' );
        view.addInlineEditingAttributes( 'content', 'advanced' );
        #>
        <h2 {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</h2>
        <div {{{ view.getRenderAttributeString( 'description' ) }}}>{{{ settings.description }}}</div>
        <div {{{ view.getRenderAttributeString( 'content' ) }}}>{{{ settings.content }}}</div>
        <?php
    }



}