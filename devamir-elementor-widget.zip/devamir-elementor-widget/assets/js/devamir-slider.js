document.addEventListener('DOMContentLoaded', function () {
    var thumbsSwiper = new Swiper('.thumbs-swiper', {
        slidesPerView: 3,
        spaceBetween: 10,
        watchSlidesProgress: true,
        direction: 'horizontal',
    });

    var mainSwiper = new Swiper('.main-swiper', {
        spaceBetween: 10,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        thumbs: {
            swiper: thumbsSwiper,
        },
    });
});
