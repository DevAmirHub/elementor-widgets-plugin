<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function devamir_enqueue_slider_assets() {
    // Swiper CSS و JS از CDN
    wp_register_style( 'swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css', [], '10.0.0' );
    wp_register_script( 'swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js', [], '10.0.0', true );

    // استایل و اسکریپت‌های سفارشی از پوشه assets
    wp_register_style( 'devamir-slider-css', DEVAMIR_ASSETS_css_url . 'devamir-slider.css', [], '1.0' );
    wp_register_script( 'devamir-slider-js', DEVAMIR_ASSETS_js_url . 'devamir-slider.js', [ 'swiper-js' ], '1.0', true );

    // الان باید آن‌ها را enqueue کنیم:
    wp_enqueue_style( 'swiper-css' );
    wp_enqueue_style( 'devamir-slider-css' );

    wp_enqueue_script( 'swiper-js' );
    wp_enqueue_script( 'devamir-slider-js' );
}
add_action( 'wp_enqueue_scripts', 'devamir_enqueue_slider_assets' );
